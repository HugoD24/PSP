package SIMULACRO_EXAMEN.Cliente_servidor;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
    public static void main(String[] args) {

         int puerto = 1805;

        try {
            ServerSocket servidor = new ServerSocket(puerto);
                while(true) {
                 System.out.println("Servidor iniciado");

                 Socket socket = servidor.accept();
                 System.out.println("Cliente conectado con numero de socket" + socket.getRemoteSocketAddress().toString());
                 Gestor gestor = new Gestor(socket);
                 new Thread(gestor).start();


                 }

              } catch (IOException e) {
              System.out.println("Error al conectar el servidor");
             throw new RuntimeException(e);
        }


    }
}