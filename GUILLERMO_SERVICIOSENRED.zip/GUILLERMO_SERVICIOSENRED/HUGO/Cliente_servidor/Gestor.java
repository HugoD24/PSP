package SIMULACRO_EXAMEN.Cliente_servidor;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;

public class Gestor implements Runnable{
    Socket socket;
    String fichero ="Simulacro_examen_ftp.txt";
    ArrayList<Integer> lista=new ArrayList<>();


    public Gestor(Socket socket) {
        this.socket = socket;
    }
    @Override
    public void run() {


        try {
            DataInputStream entrada = new DataInputStream(socket.getInputStream());
            DataOutputStream salida = new DataOutputStream(socket.getOutputStream());
            BufferedReader entrada1 = new BufferedReader(new FileReader(fichero));
            String linea;
            while ((linea = entrada1.readLine()) != null) {
                lista.add(Integer.parseInt(linea));
            }


            Collections.shuffle(lista);
            int correcto=0;
            int incorrecto=0;
            for (int i = 0; i < lista.size(); i++) {
                salida.writeBoolean(true);
                salida.writeInt(lista.get(i));
                String respuesta = entrada.readUTF();

                if(respuesta.equalsIgnoreCase("positivo") && lista.get(i)>0 || respuesta.equalsIgnoreCase("negativo") && lista.get(i)<0 || respuesta.equalsIgnoreCase("cero")&& lista.get(i)==0){
                    salida.writeUTF("Correcto");
                    correcto++;
                    System.out.println("cliente con socket"+ socket.getRemoteSocketAddress()+ "ha acertado la respuesta del numero"+lista.get(i));
                }else {
                    salida.writeUTF("Incorrecto");
                    System.out.println("cliente con socket"+ socket.getRemoteSocketAddress()+ "ha fallado la respuesta del numero"+lista.get(i));
                    incorrecto++;

                }
            }
            salida.writeBoolean(false);
            System.out.println("Numero total de numero enviados: " + lista.size());
            System.out.println("Numero total respuestas correctas"+ correcto);
            System.out.println("Numero total incorrectos"+ incorrecto);
            String resumen= "Numero total de numero enviados: " + lista.size() + " Numero total respuestas correctas "+ correcto +" Numero total incorrectos "+ incorrecto;
            salida.writeUTF(resumen);

            salida.close();
            entrada.close();
            socket.close();
            entrada1.close();






        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }
}

