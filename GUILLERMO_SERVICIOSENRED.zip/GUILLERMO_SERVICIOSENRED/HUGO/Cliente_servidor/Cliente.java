package SIMULACRO_EXAMEN.Cliente_servidor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {
    public static void main(String[] args) {

        try {
            Socket socket = new Socket("localhost",1805);
            DataOutputStream salida = new DataOutputStream(socket.getOutputStream());
            DataInputStream entrada = new DataInputStream(socket.getInputStream());
            Scanner scn = new Scanner(System.in);

            while(entrada.readBoolean()){
                int numero = entrada.readInt();
                System.out.println("Servidor te manda este numero;"+ numero);
                System.out.println("Es positivo? negativo? o es cero? ");
                String respuesta= scn.nextLine();
                salida.writeUTF(respuesta);
                String respuestaServidor= entrada.readUTF();
                System.out.println("Servidor dice que tu respuesta es"+ respuestaServidor);
            }
            System.out.println("Este es el resumen ");
           String respuesta= entrada.readUTF();
            System.out.println(respuesta);
            entrada.close();
            salida.close();
            socket.close();



        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}