package SIMULACRO_EXAMEN.api_res;

import com.google.gson.*;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Main {
    public static void main(String[] args) {


        Scanner scn = new Scanner(System.in);
        String api="https://api.chucknorris.io/jokes/random";
        System.out.println("Cuantos chistes quieres que devuelva la api?");
        int numero= scn.nextInt();
        String fichero= "ChuckNorris.txt";
       // DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");
        //String nombreFichero =LocalDateTime.now().format(formatter)+ "-ChuckNorris.txt";


        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder().uri(URI.create(api)).GET().build();
        HttpResponse<String> response = null;
        int peticiones=0;


        Set<String> idsUnicos = new HashSet<>();
        Set<String> idsDuplicados = new HashSet<>();


            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter(fichero,true));
                for (int i = 0; i <numero; i++) {
                    peticiones++;
                    response = client.send (request, HttpResponse.BodyHandlers.ofString());
                    System.out.println("Respuesta numero "+ (i+1));
                   // System.out.println(response.body());
                    //esto es para printear el json bonito en consola
                    JsonElement jsonElement = JsonParser.parseString(response.body());
                    Gson gson = new GsonBuilder().setPrettyPrinting().create();
                    System.out.println(gson.toJson(jsonElement));
                    JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
                    String id= json.get("id").getAsString();
                    String value= json.get("value").getAsString();

                    if (!idsUnicos.add(id)) {
                        idsDuplicados.add(id);
                    } else {
                        writer.write("ID: " + id);
                        writer.newLine();
                        writer.write("CHISTE: " + value);
                        writer.newLine();
                        writer.newLine();
                    }
                }
                System.out.println("Peticiones realizadas"+peticiones);
                writer.close();


                System.out.println("Chistes distintos almacenados: " + idsUnicos.size());
                System.out.println("IDs duplicados descartados: " + idsDuplicados);




            } catch (IOException  | InterruptedException e) {
                throw new RuntimeException(e);
           }


    }
}