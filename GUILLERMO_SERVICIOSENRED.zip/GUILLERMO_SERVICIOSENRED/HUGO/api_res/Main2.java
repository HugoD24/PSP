package SIMULACRO_EXAMEN.api_res;

import java.util.Scanner;

public class Main2 {
    /*EJERCICIO – API de Chistes de Chuck Norris
Usando la API pública:
https://api.chucknorris.io/jokes/random
desarrolla una aplicación en Java que realice lo siguiente:
La aplicación solicitará por consola un número n de chistes a consultar.
A continuación realizará n peticiones HTTP GET a la API para obtener chistes aleatorios.
De cada respuesta JSON deberás extraer:
id → identificador del chiste
value → el texto del chiste
La aplicación deberá guardar todos los chistes distintos en un fichero .txt con nombre:
yyyyMMdd-HHmmss-ChuckNorris.txt
Cada chiste se escribirá en el fichero en un bloque de dos líneas:
ID: <id>
CHISTE: <value>
Además, tras finalizar todas las peticiones, la aplicación deberá mostrar por consola:
Número total de peticiones realizadas
Número de chistes distintos almacenados
Lista de IDs duplicados que se descartaron
*/
    public static void main(String[] args) {

        String api= "https://api.chucknorris.io/jokes/random";
        System.out.println("Cuantos chistes quieres que saque");
        Scanner sc = new Scanner(System.in);
        int numero= sc.nextInt();

    }
}